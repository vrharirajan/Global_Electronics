use global_electronics;
-- Explore Dataset --

-- Snaphsot of the table / see the result of the query in "sql_requests_snapshots/explore_customers_1" --
SELECT * FROM customers LIMIT 100;

-- Number of rows in the table / see the result of the query in "sql_requests_snapshots/explore_customers_2" --
SELECT COUNT(*) AS NumberOfCustomers FROM customers;

-- Number of people by gender / see the result of the query in "sql_requests_snapshots/explore_customers_3" --
SELECT Gender, COUNT(*) AS NumberOfCustomers
FROM customers
GROUP BY Gender
ORDER BY Gender DESC;

-- Compute total number of people by gender with their corresponding proportions / see the result of the query in "sql_requests_snapshots/explore_customers_4" --
WITH group_by_gender AS (SELECT Gender, COUNT(*) AS NumberOfCustomers FROM customers 
GROUP BY Gender ORDER BY NumberOfCustomers DESC)
SELECT NumberOfCustomers, Gender, (NumberOfCustomers / (SELECT SUM(NumberOfCustomers) FROM group_by_gender)) 
AS Proportion FROM group_by_gender
GROUP BY Gender ORDER BY NumberOfCustomers DESC;

-- Number of people by Country / see the result of the query in "sql_requests_snapshots/explore_customers_5" --
SELECT Country, COUNT(*) AS NumberOfCustomers
FROM customers
GROUP BY Country
ORDER BY NumberOfCustomers desc;

-- Compute total number of people by Country with their corresponding proportions / see the result of the query in "sql_requests_snapshots/explore_customers_6" --
WITH group_by_country AS (SELECT Country, COUNT(*) AS NumberOfCustomers FROM customers 
GROUP BY Country ORDER BY NumberOfCustomers DESC)
SELECT Country, NumberOfCustomers, (NumberOfCustomers / (SELECT SUM(NumberOfCustomers) FROM group_by_country)) 
AS Proportion FROM group_by_country
GROUP BY Country ORDER BY NumberOfCustomers DESC;

-- Compute total number of people by Continent with their corresponding proportions / see the result of the query in "sql_requests_snapshots/explore_customers_7" --
WITH group_by_continent AS (SELECT Continent, COUNT(*) AS NumberOfCustomers FROM customers 
GROUP BY Continent ORDER BY NumberOfCustomers DESC)
SELECT Continent, NumberOfCustomers, (NumberOfCustomers / (SELECT SUM(NumberOfCustomers) FROM group_by_continent)) 
AS Proportion FROM group_by_continent
GROUP BY Continent ORDER BY NumberOfCustomers DESC;

-- Compute Total Sales Quantity by Brand and Category wise / see the result of the query in "sql_requests_snapshots/explore_products_1"--
SELECT products.Brand, products.Category, SUM(sales.Quantity) AS TotalSalesQuantity 
FROM sales INNER JOIN products on sales.ProductKey = products.ProductKey 
GROUP BY products.Brand, products.Category order by TotalSalesQuantity desc;

-- Compute Total Product Count by Product Brand wise / see the result of the query in "sql_requests_snapshots/explore_Product_2"--
select Brand, count(`Product Name`) as `No.ofProducts` from products 
group by Brand order by `No.ofProducts` desc;

-- Compute Total Product Count by Product Category wise / see the result of the query in "sql_requests_snapshots/explore_Product_3"--
select Category, count(`Product Name`) as `No.ofProducts` from products 
group by Category order by `No.ofProducts` DESC;

-- Compute Total Sales Quantity by Country wise / see the result of the query in "sql_requests_snapshots/explore_stores_1"--
SELECT stores.Country, SUM(sales.Quantity) AS TotalSalesQuantity 
FROM sales INNER JOIN stores on sales.StoreKey = stores.StoreKey 
GROUP BY stores.Country order by TotalSalesQuantity desc;

-- Compute Total Sales Quantity by Country wise / see the result of the query in "sql_requests_snapshots/explore_stores_2"--
SELECT * from stores order by `Square Meters` DESC;